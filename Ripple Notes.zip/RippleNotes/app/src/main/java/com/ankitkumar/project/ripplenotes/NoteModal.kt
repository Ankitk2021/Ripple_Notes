package com.ankitkumar.project.ripplenotes

data class NoteModal (val title : String , val desc : String) {

}